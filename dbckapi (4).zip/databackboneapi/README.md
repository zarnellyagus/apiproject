# databackboneapi

Spring Boot REST API dengan koneksi PostgreSQL (AWS RDS).

## Konfigurasi Proyek

| Properti | Nilai |
|---|---|
| **Build Tool** | Gradle - Groovy |
| **Language** | Java 17 |
| **Spring Boot** | 3.5.14 |
| **Group** | com.example |
| **Artifact** | databackboneapi |
| **Packaging** | Jar |

## Dependencies

- Spring Web (REST API)
- Spring Data JPA (ORM)
- PostgreSQL Driver (JDBC)
- Lombok (code generation)

## Database (AWS RDS PostgreSQL)

| Parameter | Nilai |
|---|---|
| Host | slf-ap-jkt-dms-pd-id-pgiddbdv.cgodsihubzrg.ap-southeast-3.rds.amazonaws.com |
| Port | 5020 |
| Database | pgidb |
| Username | pgidb |
| DB Instance | slf-ap-jkt-dms-pd-id-pgiddbdv |

## Cara Menjalankan

```bash
# Menggunakan Gradle Wrapper
./gradlew bootRun

# Build JAR
./gradlew build

# Jalankan JAR
java -jar build/libs/databackboneapi-0.0.1-SNAPSHOT.jar
```

## API Endpoints

### Health Check
| Method | URL | Deskripsi |
|---|---|---|
| GET | `/api/v1/health` | Status aplikasi dan DB |
| GET | `/api/v1/info` | Informasi aplikasi |

### Data Records CRUD
| Method | URL | Deskripsi |
|---|---|---|
| GET | `/api/v1/records` | Ambil semua records |
| GET | `/api/v1/records/{id}` | Ambil record by ID |
| GET | `/api/v1/records/search?name=&category=&status=` | Search records |
| GET | `/api/v1/records/category/{category}` | Filter by kategori |
| GET | `/api/v1/records/status/{status}` | Filter by status |
| GET | `/api/v1/records/count` | Hitung total records |
| POST | `/api/v1/records` | Buat record baru |
| PUT | `/api/v1/records/{id}` | Update record |
| DELETE | `/api/v1/records/{id}` | Hapus record |

## Contoh Request

### POST /api/v1/records
```json
{
  "name": "Data Contoh",
  "description": "Deskripsi data",
  "category": "KATEGORI_A",
  "status": "ACTIVE",
  "value": 100000.00,
  "metadata": "{\"key\": \"value\"}"
}
```

### Response Format
```json
{
  "success": true,
  "message": "Data berhasil dibuat",
  "data": {
    "id": 1,
    "name": "Data Contoh",
    "description": "Deskripsi data",
    "category": "KATEGORI_A",
    "status": "ACTIVE",
    "value": 100000.00,
    "metadata": "{\"key\": \"value\"}",
    "createdAt": "2026-06-08T18:00:00",
    "updatedAt": "2026-06-08T18:00:00"
  },
  "timestamp": "2026-06-08T18:00:00"
}
```

## Struktur Proyek

```
databackboneapi/
├── src/
│   └── main/
│       ├── java/com/example/databackboneapi/
│       │   ├── DatabackboneapiApplication.java
│       │   ├── config/
│       │   │   ├── DatabaseConfig.java
│       │   │   └── GlobalExceptionHandler.java
│       │   ├── controller/
│       │   │   ├── DataRecordController.java
│       │   │   └── HealthController.java
│       │   ├── dto/
│       │   │   ├── ApiResponse.java
│       │   │   ├── DataRecordDto.java
│       │   │   └── DataRecordRequest.java
│       │   ├── entity/
│       │   │   └── DataRecord.java
│       │   ├── repository/
│       │   │   └── DataRecordRepository.java
│       │   └── service/
│       │       └── DataRecordService.java
│       └── resources/
│           └── application.properties
├── build.gradle
├── settings.gradle
└── README.md
```
