package com.example.databackboneapi.controller;

import com.example.databackboneapi.dto.ApiResponse;
import com.example.databackboneapi.dto.DataRecordDto;
import com.example.databackboneapi.dto.DataRecordRequest;
import com.example.databackboneapi.service.DataRecordService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/records")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class DataRecordController {

    private final DataRecordService dataRecordService;

    /**
     * GET /api/v1/records
     * Ambil semua data records
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<DataRecordDto>>> findAll() {
        List<DataRecordDto> records = dataRecordService.findAll();
        return ResponseEntity.ok(ApiResponse.success(
                "Data berhasil diambil",
                records,
                records.size()
        ));
    }

    /**
     * GET /api/v1/records/{id}
     * Ambil data record berdasarkan ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<DataRecordDto>> findById(@PathVariable Long id) {
        return dataRecordService.findById(id)
                .map(dto -> ResponseEntity.ok(ApiResponse.success("Data ditemukan", dto)))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(ApiResponse.error("Data dengan id " + id + " tidak ditemukan")));
    }

    /**
     * GET /api/v1/records/search?name=&category=&status=
     * Search data records dengan filter
     */
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<DataRecordDto>>> search(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String status) {
        List<DataRecordDto> records = dataRecordService.search(name, category, status);
        return ResponseEntity.ok(ApiResponse.success(
                "Hasil pencarian",
                records,
                records.size()
        ));
    }

    /**
     * GET /api/v1/records/category/{category}
     * Ambil data berdasarkan kategori
     */
    @GetMapping("/category/{category}")
    public ResponseEntity<ApiResponse<List<DataRecordDto>>> findByCategory(@PathVariable String category) {
        List<DataRecordDto> records = dataRecordService.findByCategory(category);
        return ResponseEntity.ok(ApiResponse.success(
                "Data kategori " + category,
                records,
                records.size()
        ));
    }

    /**
     * GET /api/v1/records/status/{status}
     * Ambil data berdasarkan status
     */
    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse<List<DataRecordDto>>> findByStatus(@PathVariable String status) {
        List<DataRecordDto> records = dataRecordService.findByStatus(status);
        return ResponseEntity.ok(ApiResponse.success(
                "Data status " + status,
                records,
                records.size()
        ));
    }

    /**
     * POST /api/v1/records
     * Buat data record baru
     */
    @PostMapping
    public ResponseEntity<ApiResponse<DataRecordDto>> create(@Valid @RequestBody DataRecordRequest request) {
        DataRecordDto created = dataRecordService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Data berhasil dibuat", created));
    }

    /**
     * PUT /api/v1/records/{id}
     * Update data record
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<DataRecordDto>> update(
            @PathVariable Long id,
            @Valid @RequestBody DataRecordRequest request) {
        return dataRecordService.update(id, request)
                .map(dto -> ResponseEntity.ok(ApiResponse.success("Data berhasil diupdate", dto)))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(ApiResponse.error("Data dengan id " + id + " tidak ditemukan")));
    }

    /**
     * DELETE /api/v1/records/{id}
     * Hapus data record
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        if (dataRecordService.delete(id)) {
            return ResponseEntity.ok(ApiResponse.success("Data berhasil dihapus", null));
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiResponse.error("Data dengan id " + id + " tidak ditemukan"));
    }

    /**
     * GET /api/v1/records/count
     * Hitung total records
     */
    @GetMapping("/count")
    public ResponseEntity<ApiResponse<Long>> count() {
        long total = dataRecordService.count();
        return ResponseEntity.ok(ApiResponse.success("Total records", total));
    }
}
