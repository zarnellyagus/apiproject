package com.example.databackboneapi.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DataRecordRequest {

    @NotBlank(message = "Name tidak boleh kosong")
    @Size(max = 255, message = "Name maksimal 255 karakter")
    private String name;

    private String description;

    @Size(max = 100, message = "Category maksimal 100 karakter")
    private String category;

    @Size(max = 50, message = "Status maksimal 50 karakter")
    private String status;

    private BigDecimal value;

    private String metadata;
}
