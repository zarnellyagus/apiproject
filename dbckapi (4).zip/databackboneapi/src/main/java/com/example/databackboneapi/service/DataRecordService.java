package com.example.databackboneapi.service;

import com.example.databackboneapi.dto.DataRecordDto;
import com.example.databackboneapi.dto.DataRecordRequest;
import com.example.databackboneapi.entity.DataRecord;
import com.example.databackboneapi.repository.DataRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class DataRecordService {

    private final DataRecordRepository dataRecordRepository;

    public List<DataRecordDto> findAll() {
        log.info("Mengambil semua data records");
        return dataRecordRepository.findAll()
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public Optional<DataRecordDto> findById(Long id) {
        log.info("Mengambil data record dengan id: {}", id);
        return dataRecordRepository.findById(id).map(this::toDto);
    }

    public List<DataRecordDto> search(String name, String category, String status) {
        log.info("Search records - name: {}, category: {}, status: {}", name, category, status);
        return dataRecordRepository.searchRecords(name, category, status)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public List<DataRecordDto> findByCategory(String category) {
        return dataRecordRepository.findByCategory(category)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public List<DataRecordDto> findByStatus(String status) {
        return dataRecordRepository.findByStatus(status)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public DataRecordDto create(DataRecordRequest request) {
        log.info("Membuat data record baru: {}", request.getName());
        DataRecord entity = DataRecord.builder()
                .name(request.getName())
                .description(request.getDescription())
                .category(request.getCategory())
                .status(request.getStatus() != null ? request.getStatus() : "ACTIVE")
                .value(request.getValue())
                .metadata(request.getMetadata())
                .build();
        DataRecord saved = dataRecordRepository.save(entity);
        return toDto(saved);
    }

    @Transactional
    public Optional<DataRecordDto> update(Long id, DataRecordRequest request) {
        log.info("Update data record id: {}", id);
        return dataRecordRepository.findById(id).map(entity -> {
            entity.setName(request.getName());
            entity.setDescription(request.getDescription());
            entity.setCategory(request.getCategory());
            entity.setStatus(request.getStatus());
            entity.setValue(request.getValue());
            entity.setMetadata(request.getMetadata());
            return toDto(dataRecordRepository.save(entity));
        });
    }

    @Transactional
    public boolean delete(Long id) {
        log.info("Menghapus data record id: {}", id);
        if (dataRecordRepository.existsById(id)) {
            dataRecordRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public long count() {
        return dataRecordRepository.count();
    }

    private DataRecordDto toDto(DataRecord entity) {
        return DataRecordDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .description(entity.getDescription())
                .category(entity.getCategory())
                .status(entity.getStatus())
                .value(entity.getValue())
                .metadata(entity.getMetadata())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }
}
