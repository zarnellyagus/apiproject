package com.example.databackboneapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabackboneapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabackboneapiApplication.class, args);
	}

}
