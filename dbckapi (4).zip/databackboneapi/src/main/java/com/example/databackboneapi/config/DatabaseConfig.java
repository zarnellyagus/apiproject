package com.example.databackboneapi.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.example.databackboneapi.repository")
public class DatabaseConfig {
    // Konfigurasi tambahan jika diperlukan
}
