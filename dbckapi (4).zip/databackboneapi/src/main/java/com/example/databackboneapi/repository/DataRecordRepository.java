package com.example.databackboneapi.repository;

import com.example.databackboneapi.entity.DataRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DataRecordRepository extends JpaRepository<DataRecord, Long> {

    List<DataRecord> findByCategory(String category);

    List<DataRecord> findByStatus(String status);

    List<DataRecord> findByCategoryAndStatus(String category, String status);

    @Query("SELECT d FROM DataRecord d WHERE " +
           "(:name IS NULL OR LOWER(d.name) LIKE LOWER(CONCAT('%', :name, '%'))) AND " +
           "(:category IS NULL OR d.category = :category) AND " +
           "(:status IS NULL OR d.status = :status)")
    List<DataRecord> searchRecords(
            @Param("name") String name,
            @Param("category") String category,
            @Param("status") String status
    );

    @Query(value = "SELECT COUNT(*) FROM data_records", nativeQuery = true)
    long countAllRecords();
}
