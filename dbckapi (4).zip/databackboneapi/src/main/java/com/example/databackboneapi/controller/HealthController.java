package com.example.databackboneapi.controller;

import com.example.databackboneapi.dto.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class HealthController {

    private final DataSource dataSource;

    /**
     * GET /api/v1/health
     * Cek status aplikasi dan koneksi database
     */
    @GetMapping("/health")
    public ResponseEntity<ApiResponse<Map<String, Object>>> health() {
        Map<String, Object> healthInfo = new HashMap<>();
        healthInfo.put("application", "databackboneapi");
        healthInfo.put("timestamp", LocalDateTime.now().toString());

        // Cek koneksi database
        try (Connection conn = dataSource.getConnection()) {
            healthInfo.put("database", "UP");
            healthInfo.put("db_product", conn.getMetaData().getDatabaseProductName());
            healthInfo.put("db_version", conn.getMetaData().getDatabaseProductVersion());
        } catch (Exception e) {
            healthInfo.put("database", "DOWN");
            healthInfo.put("db_error", e.getMessage());
        }

        healthInfo.put("status", "UP");
        return ResponseEntity.ok(ApiResponse.success("Aplikasi berjalan normal", healthInfo));
    }

    /**
     * GET /api/v1/info
     * Informasi aplikasi
     */
    @GetMapping("/info")
    public ResponseEntity<ApiResponse<Map<String, String>>> info() {
        Map<String, String> info = new HashMap<>();
        info.put("name", "databackboneapi");
        info.put("group", "com.example");
        info.put("version", "0.0.1-SNAPSHOT");
        info.put("description", "Data Backbone API - Spring Boot REST API with PostgreSQL");
        info.put("java_version", System.getProperty("java.version"));
        return ResponseEntity.ok(ApiResponse.success("Informasi aplikasi", info));
    }
}
