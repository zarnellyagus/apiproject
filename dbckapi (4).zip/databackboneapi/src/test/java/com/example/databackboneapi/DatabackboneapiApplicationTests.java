package com.example.databackboneapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabackboneapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
