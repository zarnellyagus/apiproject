package com.databackbone.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataBackboneApplication {

    public static void main(String[] args) {
        SpringApplication.run(DataBackboneApplication.class, args);
    }
}