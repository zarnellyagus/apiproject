package com.databackbone.api.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/v1")
public class HealthController {

    @Autowired
    private DataSource dataSource;

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("service", "databackbone-api");
        response.put("status", "UP");
        response.put("timestamp", LocalDateTime.now().toString());

        try (Connection conn = dataSource.getConnection()) {
            DatabaseMetaData meta = conn.getMetaData();
            Map<String, String> dbInfo = new LinkedHashMap<>();
            dbInfo.put("status", "CONNECTED");
            dbInfo.put("product", meta.getDatabaseProductName());
            dbInfo.put("version", meta.getDatabaseProductVersion());
            dbInfo.put("url", meta.getURL());
            response.put("database", dbInfo);
        } catch (Exception e) {
            Map<String, String> dbInfo = new LinkedHashMap<>();
            dbInfo.put("status", "DISCONNECTED");
            dbInfo.put("error", e.getMessage());
            response.put("database", dbInfo);
            response.put("status", "DEGRADED");
            log.error("DB health check failed: {}", e.getMessage());
        }

        return ResponseEntity.ok(response);
    }

    @GetMapping("/ping")
    public ResponseEntity<Map<String, String>> ping() {
        Map<String, String> response = new LinkedHashMap<>();
        response.put("message", "pong");
        response.put("timestamp", LocalDateTime.now().toString());
        return ResponseEntity.ok(response);
    }
}