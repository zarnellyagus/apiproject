package com.databackbone.api.config;

import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;

@Slf4j
@Configuration
public class DatabaseConfig {

    @Autowired
    private DataSource dataSource;

    @PostConstruct
    public void checkDatabaseConnection() {
        try (Connection connection = dataSource.getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            log.info("==============================================");
            log.info("Database connection OK");
            log.info("DB Product  : {}", metaData.getDatabaseProductName());
            log.info("DB Version  : {}", metaData.getDatabaseProductVersion());
            log.info("JDBC URL    : {}", metaData.getURL());
            log.info("Username    : {}", metaData.getUserName());
            if (dataSource instanceof HikariDataSource hikariDataSource) {
                log.info("Pool Name   : {}", hikariDataSource.getPoolName());
                log.info("Pool Size   : {}", hikariDataSource.getMaximumPoolSize());
            }
            log.info("==============================================");
        } catch (Exception e) {
            log.error("==============================================");
            log.error("Database connection FAILED: {}", e.getMessage());
            log.error("==============================================");
            throw new RuntimeException("Failed to connect to database at startup", e);
        }
    }
}