package com.example.databackbone.controller;

import com.example.databackbone.dto.ApiResponse;
import com.example.databackbone.dto.DataRecordRequest;
import com.example.databackbone.dto.DataRecordResponse;
import com.example.databackbone.dto.PageResponse;
import com.example.databackbone.service.DataRecordService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/data-records")
@RequiredArgsConstructor
public class DataRecordController {

    private final DataRecordService service;

    /**
     * POST /api/v1/data-records
     * Create a new record
     */
    @PostMapping
    public ResponseEntity<ApiResponse<DataRecordResponse>> create(
            @Valid @RequestBody DataRecordRequest request) {
        DataRecordResponse data = service.create(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("DataRecord created successfully", data));
    }

    /**
     * GET /api/v1/data-records
     * Get all records (paginated)
     */
    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<DataRecordResponse>>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        PageResponse<DataRecordResponse> data = service.getAll(page, size, sortBy, sortDir);
        return ResponseEntity.ok(ApiResponse.success("Data retrieved successfully", data));
    }

    /**
     * GET /api/v1/data-records/{id}
     * Get record by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<DataRecordResponse>> getById(@PathVariable Long id) {
        DataRecordResponse data = service.getById(id);
        return ResponseEntity.ok(ApiResponse.success("DataRecord found", data));
    }

    /**
     * PUT /api/v1/data-records/{id}
     * Update record
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<DataRecordResponse>> update(
            @PathVariable Long id,
            @Valid @RequestBody DataRecordRequest request) {
        DataRecordResponse data = service.update(id, request);
        return ResponseEntity.ok(ApiResponse.success("DataRecord updated successfully", data));
    }

    /**
     * DELETE /api/v1/data-records/{id}
     * Delete record
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok(ApiResponse.success("DataRecord deleted successfully", null));
    }

    /**
     * GET /api/v1/data-records/search
     * Search with filters
     */
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<PageResponse<DataRecordResponse>>> search(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Boolean isActive,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        PageResponse<DataRecordResponse> data = service.search(keyword, category, isActive, page, size);
        return ResponseEntity.ok(ApiResponse.success("Search results", data));
    }

    /**
     * GET /api/v1/data-records/categories
     * Get all distinct categories
     */
    @GetMapping("/categories")
    public ResponseEntity<ApiResponse<List<String>>> getCategories() {
        List<String> categories = service.getCategories();
        return ResponseEntity.ok(ApiResponse.success("Categories retrieved", categories));
    }

    /**
     * PATCH /api/v1/data-records/{id}/toggle-active
     * Toggle active/inactive status
     */
    @PatchMapping("/{id}/toggle-active")
    public ResponseEntity<ApiResponse<DataRecordResponse>> toggleActive(@PathVariable Long id) {
        DataRecordResponse data = service.toggleActive(id);
        return ResponseEntity.ok(ApiResponse.success("Status toggled successfully", data));
    }
}
