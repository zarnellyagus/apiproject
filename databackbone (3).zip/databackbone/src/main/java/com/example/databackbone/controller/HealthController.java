package com.example.databackbone.controller;

import com.example.databackbone.dto.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class HealthController {

    private final JdbcTemplate jdbcTemplate;

    /**
     * GET /api/v1/health
     * Custom health check with DB connectivity
     */
    @GetMapping("/health")
    public ApiResponse<Map<String, Object>> health() {
        Map<String, Object> info = new HashMap<>();
        info.put("application", "databackbone");
        info.put("status", "UP");

        try {
            jdbcTemplate.queryForObject("SELECT 1", Integer.class);
            info.put("database", "CONNECTED");
            info.put("dbHost", "slf-ap-jkt-dms-pd-id-pgiddbdv.cgodsihubzrg.ap-southeast-3.rds.amazonaws.com");
            info.put("dbName", "pgidb");
        } catch (Exception e) {
            info.put("database", "DISCONNECTED");
            info.put("dbError", e.getMessage());
        }

        return ApiResponse.success("Health check OK", info);
    }
}
