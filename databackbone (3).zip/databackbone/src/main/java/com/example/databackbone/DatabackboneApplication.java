package com.example.databackbone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabackboneApplication {

    public static void main(String[] args) {
        SpringApplication.run(DatabackboneApplication.class, args);
    }
}
