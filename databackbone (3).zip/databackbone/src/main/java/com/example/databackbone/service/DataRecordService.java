package com.example.databackbone.service;

import com.example.databackbone.dto.DataRecordRequest;
import com.example.databackbone.dto.DataRecordResponse;
import com.example.databackbone.dto.PageResponse;
import com.example.databackbone.entity.DataRecord;
import com.example.databackbone.exception.ResourceNotFoundException;
import com.example.databackbone.repository.DataRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataRecordService {

    private final DataRecordRepository repository;

    // CREATE
    @Transactional
    public DataRecordResponse create(DataRecordRequest request) {
        log.info("Creating new DataRecord with name: {}", request.getName());
        DataRecord entity = DataRecord.builder()
                .name(request.getName())
                .description(request.getDescription())
                .category(request.getCategory())
                .isActive(request.getIsActive() != null ? request.getIsActive() : true)
                .build();
        DataRecord saved = repository.save(entity);
        log.info("DataRecord created with id: {}", saved.getId());
        return mapToResponse(saved);
    }

    // READ ALL (paginated)
    @Transactional(readOnly = true)
    public PageResponse<DataRecordResponse> getAll(int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<DataRecord> pageData = repository.findAll(pageable);
        return buildPageResponse(pageData);
    }

    // READ BY ID
    @Transactional(readOnly = true)
    public DataRecordResponse getById(Long id) {
        DataRecord entity = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DataRecord", "id", id));
        return mapToResponse(entity);
    }

    // UPDATE
    @Transactional
    public DataRecordResponse update(Long id, DataRecordRequest request) {
        log.info("Updating DataRecord with id: {}", id);
        DataRecord entity = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DataRecord", "id", id));

        entity.setName(request.getName());
        entity.setDescription(request.getDescription());
        entity.setCategory(request.getCategory());
        if (request.getIsActive() != null) {
            entity.setIsActive(request.getIsActive());
        }

        DataRecord updated = repository.save(entity);
        log.info("DataRecord updated with id: {}", updated.getId());
        return mapToResponse(updated);
    }

    // DELETE
    @Transactional
    public void delete(Long id) {
        log.info("Deleting DataRecord with id: {}", id);
        DataRecord entity = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DataRecord", "id", id));
        repository.delete(entity);
        log.info("DataRecord deleted with id: {}", id);
    }

    // SEARCH with filters
    @Transactional(readOnly = true)
    public PageResponse<DataRecordResponse> search(String keyword, String category,
                                                    Boolean isActive, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<DataRecord> pageData = repository.findByFilters(keyword, category, isActive, pageable);
        return buildPageResponse(pageData);
    }

    // GET CATEGORIES
    @Transactional(readOnly = true)
    public List<String> getCategories() {
        return repository.findDistinctCategories();
    }

    // TOGGLE ACTIVE STATUS
    @Transactional
    public DataRecordResponse toggleActive(Long id) {
        DataRecord entity = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DataRecord", "id", id));
        entity.setIsActive(!entity.getIsActive());
        return mapToResponse(repository.save(entity));
    }

    // MAPPER
    private DataRecordResponse mapToResponse(DataRecord entity) {
        return DataRecordResponse.builder()
                .id(entity.getId())
                .name(entity.getName())
                .description(entity.getDescription())
                .category(entity.getCategory())
                .isActive(entity.getIsActive())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }

    private PageResponse<DataRecordResponse> buildPageResponse(Page<DataRecord> page) {
        List<DataRecordResponse> content = page.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
        return PageResponse.<DataRecordResponse>builder()
                .content(content)
                .pageNumber(page.getNumber())
                .pageSize(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .last(page.isLast())
                .first(page.isFirst())
                .build();
    }
}
