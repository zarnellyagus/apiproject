package com.example.databackbone.repository;

import com.example.databackbone.entity.DataRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DataRecordRepository extends JpaRepository<DataRecord, Long> {

    // Find by category
    Page<DataRecord> findByCategory(String category, Pageable pageable);

    // Find by isActive
    Page<DataRecord> findByIsActive(Boolean isActive, Pageable pageable);

    // Find by name containing (search)
    Page<DataRecord> findByNameContainingIgnoreCase(String name, Pageable pageable);

    // Custom query: search by name or description
    @Query("SELECT d FROM DataRecord d WHERE " +
           "(:keyword IS NULL OR LOWER(d.name) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(d.description) LIKE LOWER(CONCAT('%', :keyword, '%'))) " +
           "AND (:category IS NULL OR d.category = :category) " +
           "AND (:isActive IS NULL OR d.isActive = :isActive)")
    Page<DataRecord> findByFilters(
            @Param("keyword") String keyword,
            @Param("category") String category,
            @Param("isActive") Boolean isActive,
            Pageable pageable
    );

    // Get distinct categories
    @Query("SELECT DISTINCT d.category FROM DataRecord d ORDER BY d.category")
    List<String> findDistinctCategories();

    // Count by category
    long countByCategory(String category);

    // Count active/inactive
    long countByIsActive(Boolean isActive);
}
