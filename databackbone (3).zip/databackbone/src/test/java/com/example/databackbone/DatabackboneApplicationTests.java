package com.example.databackbone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class DatabackboneApplicationTests {

    @Test
    void contextLoads() {
    }
}
