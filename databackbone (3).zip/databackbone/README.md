# Databackbone - Spring Boot REST API

Project ini adalah REST API yang dibangun dengan Spring Boot 3.5.0, Gradle, dan PostgreSQL (AWS RDS).

## Konfigurasi

- **Project**: Gradle - Groovy
- **Language**: Java 21
- **Spring Boot**: 3.5.0
- **Database**: PostgreSQL (AWS RDS ap-southeast-3)
- **Host**: `slf-ap-jkt-dms-pd-id-pgiddbdv.cgodsihubzrg.ap-southeast-3.rds.amazonaws.com`
- **Port**: `5020`
- **DB Name**: `pgidb`

## Menjalankan Aplikasi

```bash
./gradlew bootRun
```

Atau build dulu:
```bash
./gradlew build
java -jar build/libs/databackbone-0.0.1-SNAPSHOT.jar
```

## API Endpoints

Base URL: `http://localhost:8080`

### Health Check
| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| GET | `/api/v1/health` | Cek status aplikasi & koneksi DB |

### Data Records CRUD
| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| POST | `/api/v1/data-records` | Buat record baru |
| GET | `/api/v1/data-records` | Ambil semua record (paginated) |
| GET | `/api/v1/data-records/{id}` | Ambil record by ID |
| PUT | `/api/v1/data-records/{id}` | Update record |
| DELETE | `/api/v1/data-records/{id}` | Hapus record |
| GET | `/api/v1/data-records/search` | Cari dengan filter |
| GET | `/api/v1/data-records/categories` | Ambil semua kategori |
| PATCH | `/api/v1/data-records/{id}/toggle-active` | Toggle status aktif |

### Query Parameters (GET All)
- `page` - halaman (default: 0)
- `size` - jumlah per halaman (default: 10)
- `sortBy` - field untuk sorting (default: id)
- `sortDir` - asc/desc (default: asc)

### Query Parameters (Search)
- `keyword` - cari di name/description
- `category` - filter kategori
- `isActive` - filter status (true/false)
- `page` - halaman (default: 0)
- `size` - jumlah per halaman (default: 10)

## Contoh Request

### Create Record
```json
POST /api/v1/data-records
Content-Type: application/json

{
  "name": "Test Data",
  "description": "Ini adalah data test",
  "category": "TEST",
  "isActive": true
}
```

### Response Format
```json
{
  "success": true,
  "message": "DataRecord created successfully",
  "data": {
    "id": 1,
    "name": "Test Data",
    "description": "Ini adalah data test",
    "category": "TEST",
    "isActive": true,
    "createdAt": "2026-06-09T21:54:00",
    "updatedAt": "2026-06-09T21:54:00"
  },
  "timestamp": "2026-06-09T21:54:00"
}
```
